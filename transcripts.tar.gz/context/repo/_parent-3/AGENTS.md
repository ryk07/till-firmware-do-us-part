# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- **Leaderboard rank is the quality signal for bounty work** (user directive 2026-11-20): "submitted and passed" is not enough — track each entry's dev rank against the paid places, and when an entry ranks outside them, proactively propose and build a concrete improvement while deadline and quota allow. Verify the gain locally before resubmitting (submit-only-if-better) and report rank movement, not just pass/fail.
- **make.fun API key path**: `~/.makefun/credentials` nests the key at `keys["https://make.fun"].key` (an object, not a plain string) — using `keys[origin]` directly as a header sends `[object Object]` and fails with INVALID_API_KEY.
